module com.mycompany.homework5 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.homework5 to javafx.fxml;
    exports com.mycompany.homework5;
}
